#!/usr/bin/python

import serial

ser = serial.Serial('/dev/ttyUSB0', 9600, timeout=15)

ser.write('<GETCPM>>')          # Get current CPM value
print "CPM:%s" % (str(ord(ser.read(1))*256+ord(ser.read(1))))

ser.close()                     # close port
